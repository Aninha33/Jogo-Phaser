class Fase_03 extends Phaser.Scene
{

  constructor ()
  {
      // ######## acertar nome da fase ##########
      super('Fase_03');
  }

  // função para carregamento de assets
  preload ()
  {

      this.load.spritesheet('player_sp', 'assets/spritesheets/player_sp.png', { frameWidth: 64, frameHeight: 64 });
      this.load.spritesheet('robin_sp', 'assets/spritesheets/robin_sp.png', { frameWidth: 64, frameHeight: 64 });
      this.load.spritesheet('tls_firstasset', 'assets/maps/first_asset.png', { frameWidth: 32, frameHeight: 32, margin: 16 });
      this.load.spritesheet('tls_solaria', 'assets/maps/solaria.png', { frameWidth: 32, frameHeight: 32, margin: 16 });
      this.load.spritesheet('tls_topdown-forest', 'assets/maps/top-down-forest-tileset.png', { frameWidth: 32, frameHeight: 32, margin: 16 });

      this.load.image('tiles1', 'assets/maps/first_asset.png');
      this.load.image('tiles2', 'assets/maps/solaria.png');
      this.load.image('tiles3', 'assets/maps/top-down-forest-tileset.png');

      this.load.tilemapTiledJSON('fase3', 'map_prj/fase.json');
  }

  // função para criação dos elementos
  create ()
  {

      // criação do mapa e ligação com a imagem (tilesheet)
      this.map = this.make.tilemap({ key: 'fase3', tileWidth: 16, tileHeight: 16 });

      this.tileset1 = this.map.addTilesetImage('tls_firstasset', 'tiles1');
      this.tileset2 = this.map.addTilesetImage('tls_topdown-forest', 'tiles3');
      this.tileset3 = this.map.addTilesetImage('tls_solaria', 'tiles2');


      // criação das camadas
      this.ground0Layer = this.map.createLayer('ground0', [this.tileset1, this.tileset2, this.tileset3], 0, 0);
      this.groundLayer = this.map.createLayer('ground', [this.tileset1, this.tileset2, this.tileset3], 0, 0);
      this.riverLayer = this.map.createLayer('river', [this.tileset1, this.tileset2, this.tileset3], 0, 0);
      this.ground2Layer = this.map.createLayer('ground2', [this.tileset1, this.tileset2, this.tileset3], 0, 0);
      this.bridge2Layer = this.map.createLayer('bridge2', [this.tileset1, this.tileset2, this.tileset3], 0, 0);
      this.bridgeLayer = this.map.createLayer('bridge', [this.tileset1, this.tileset2, this.tileset3], 0, 0);
      this.tree1Layer = this.map.createLayer('tree1', [this.tileset1, this.tileset2, this.tileset3], 0, 0);
      this.tree2Layer = this.map.createLayer('tree2', [this.tileset1, this.tileset2, this.tileset3], 0, 0);
      this.houseLayer = this.map.createLayer('house', [this.tileset1, this.tileset2, this.tileset3], 0, 0);
      this.perfumariaLayer = this.map.createLayer('perfumaria', [this.tileset1, this.tileset2, this.tileset3], 0, 0);

      // criação do char
      // this.player = this.physics.add.sprite(40, 750, 'player_sp', 26)
      this.player = this.physics.add.sprite(800, 100, 'player_sp', 26)
      this.player.setScale(0.4);
      this.player.setSize(32, 32);
      this.player.setOffset(16, 32);
    //  player = new Actor(this, 40, 750, 'player_sp', 5);
      //player.setScale(0.3);

      //criação do robin
      this.robin = this.physics.add.sprite(995, 90, 'robin_sp', 26)
      this.robin.setScale(0.4);
      this.physics.add.collider(this.player, this.robin);
      this.robin.body.immovable = true;
      this.robin.body.moves = false;

      // camera seguindo o jogador
      this.cameras.main.startFollow(this.player, true, 0.1, 0.1);
      this.cameras.main.setZoom(2)


       //criação da colisão
      // COLISÕES NÃO ESTÃO FUNCIONANDO
       this.ground2Layer.setCollisionByExclusion([-1]);
       this.physics.add.collider(this.player, this.ground2Layer);
       this.tree1Layer.setCollisionByExclusion([-1]);
       this.physics.add.collider(this.player, this.tree1Layer);
       this.tree2Layer.setCollisionByExclusion([-1]);
       this.physics.add.collider(this.player, this.tree2Layer);
       this.houseLayer.setCollisionByExclusion([-1]);
       this.physics.add.collider(this.player, this.houseLayer);
       this.bridge2Layer.setCollisionByExclusion([-1]);
       this.physics.add.collider(this.player, this.bridge2Layer);
       this.houseLayer.setCollisionByExclusion([-1]);
       this.physics.add.collider(this.player, this.houseLayer);

      // ligação das teclas de movimento
      this.keyA = this.input.keyboard.addKey('A');
      this.keyD = this.input.keyboard.addKey('D');
      this.keyW = this.input.keyboard.addKey('W');
      this.keyS = this.input.keyboard.addKey('S');


  }

  // update é chamada a cada novo quadro
  update ()
  {
      if (this.keyD?.isDown) {
          this.player.setVelocityX(210);
          // this.player.checkFlip();
      }
      else if (this.keyA?.isDown) {
          this.player.setVelocityX(-210);
          // this.player.checkFlip();
      }
      else{
          this.player.setVelocityX(0);
      }

      // velocidade vertical
      if (this.keyW.isDown) {
          this.player.setVelocityY(-210);
      }
      else if (this.keyS.isDown) {
          this.player.setVelocityY(210);
      }
      else{
          this.player.setVelocityY(0);
      }

  }

}
