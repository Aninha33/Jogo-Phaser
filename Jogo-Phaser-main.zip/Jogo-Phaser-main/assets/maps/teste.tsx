<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="2021.03.23" name="teste" tilewidth="32" tileheight="32" tilecount="256" columns="16">
 <image source="first_asset.png" width="512" height="512"/>
</tileset>
