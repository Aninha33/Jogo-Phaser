<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="2021.03.23" name="tls_solaria" tilewidth="16" tileheight="16" tilecount="420" columns="28">
 <image source="../assets/maps/solaria.png" width="448" height="240"/>
</tileset>
