<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="2021.03.23" name="tls_top-down-forest" tilewidth="16" tileheight="16" tilecount="297" columns="27">
 <image source="../assets/maps/top-down-forest-tileset.png" width="432" height="176"/>
</tileset>
